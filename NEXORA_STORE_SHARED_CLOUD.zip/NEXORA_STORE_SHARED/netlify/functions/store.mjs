import { getStore } from "@netlify/blobs";

const store = getStore({ name: "nexora-store-data", consistency: "strong" });
const ADMIN_PASSWORD = "4150242";
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const id = () => crypto.randomUUID();
const adminOk = (req) => req.headers.get("x-admin-password") === ADMIN_PASSWORD;
async function listPrefix(prefix) {
  const out = [];
  for await (const page of store.list({ prefix, paginate: true })) {
    for (const b of page.blobs) {
      const value = await store.get(b.key, { type: "json", consistency: "strong" });
      if (value) out.push(value);
    }
  }
  return out;
}
async function readSettings() {
  return (await store.get("settings", { type: "json", consistency: "strong" })) || {
    name: "NEXORA STORE",
    badge: "سكربتات · مدن · مابات جاهزة · سكربت دلتا",
    title: "عالم NEXORA المستقبلي",
    description: "متجر رقمي للسكربتات والمـدن والمابات الجاهزة — اطلب منتجك واستلمه بسرعة.",
    delivery: "تسليم سريع",
    discord: "https://discord.gg/a87Gwxuak",
    primary: "#18DFFF",
    secondary: "#B83CFF",
    background: "#030A12",
    cards: "#0A1624",
    animations: true
  };
}

export default async (req) => {
  try {
    if (req.method === "GET") {
      const [categories, products, settings] = await Promise.all([
        listPrefix("category/"),
        listPrefix("product/"),
        readSettings()
      ]);
      let orders = [];
      if (adminOk(req)) orders = await listPrefix("order/");
      categories.sort((a,b) => (a.createdAt||0)-(b.createdAt||0));
      products.sort((a,b) => (b.createdAt||0)-(a.createdAt||0));
      orders.sort((a,b) => (b.createdAt||0)-(a.createdAt||0));
      return json({ categories, products, settings, orders });
    }
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
    const body = await req.json();
    const action = body.action;
    const now = Date.now();

    if (["addCategory","renameCategory","deleteCategory","addProduct","updateProduct","deleteProduct","saveSettings","deleteOrder"].includes(action) && !adminOk(req)) {
      return json({ error: "غير مصرح" }, 401);
    }

    if (action === "addCategory") {
      const name = String(body.name || "").trim();
      if (!name) return json({ error: "اسم القسم مطلوب" }, 400);
      const categories = await listPrefix("category/");
      if (categories.some(c => c.name === name)) return json({ error: "القسم موجود" }, 409);
      const item = { id: id(), name, createdAt: now };
      await store.set(`category/${item.id}`, JSON.stringify(item));
      return json(item, 201);
    }
    if (action === "renameCategory") {
      const categoryId = String(body.id || "");
      const name = String(body.name || "").trim();
      if (!categoryId || !name) return json({ error: "بيانات ناقصة" }, 400);
      const old = await store.get(`category/${categoryId}`, { type: "json", consistency: "strong" });
      if (!old) return json({ error: "القسم غير موجود" }, 404);
      const categories = await listPrefix("category/");
      if (categories.some(c => c.id !== categoryId && c.name === name)) return json({ error: "الاسم مستخدم" }, 409);
      old.name = name;
      old.updatedAt = now;
      await store.set(`category/${categoryId}`, JSON.stringify(old));
      return json(old);
    }
    if (action === "deleteCategory") {
      const categoryId = String(body.id || "");
      await store.delete(`category/${categoryId}`);
      const products = await listPrefix("product/");
      for (const p of products) if (p.categoryId === categoryId) {
        p.categoryId = "";
        p.updatedAt = now;
        await store.set(`product/${p.id}`, JSON.stringify(p));
      }
      return json({ ok: true });
    }
    if (action === "addProduct" || action === "updateProduct") {
      const p = body.product || {};
      const productId = action === "addProduct" ? id() : String(p.id || "");
      if (!String(p.name || "").trim()) return json({ error: "اسم المنتج مطلوب" }, 400);
      const item = {
        id: productId,
        name: String(p.name).trim(),
        categoryId: String(p.categoryId || ""),
        desc: String(p.desc || "").trim(),
        credits: String(p.credits || "").trim(),
        robux: String(p.robux || "").trim(),
        image: String(p.image || ""),
        createdAt: Number(p.createdAt) || now,
        updatedAt: now
      };
      await store.set(`product/${productId}`, JSON.stringify(item));
      return json(item, action === "addProduct" ? 201 : 200);
    }
    if (action === "deleteProduct") {
      await store.delete(`product/${String(body.id || "")}`);
      return json({ ok: true });
    }
    if (action === "saveSettings") {
      const current = await readSettings();
      const next = { ...current, ...body.settings };
      await store.set("settings", JSON.stringify(next));
      return json(next);
    }
    if (action === "addOrder") {
      const o = body.order || {};
      const item = { id: `NEX-${Date.now()}`, product: String(o.product||""), productId: String(o.productId||""), buyer: String(o.buyer||""), discord: String(o.discord||""), note: String(o.note||""), createdAt: now };
      if (!item.buyer || !item.discord || !item.product) return json({ error: "بيانات الطلب ناقصة" }, 400);
      await store.set(`order/${item.id}`, JSON.stringify(item));
      return json({ ok: true, order: item }, 201);
    }
    if (action === "deleteOrder") {
      await store.delete(`order/${String(body.id || "")}`);
      return json({ ok: true });
    }
    return json({ error: "Action not found" }, 400);
  } catch (e) {
    return json({ error: e?.message || "Server error" }, 500);
  }
};
